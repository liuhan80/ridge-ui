
// 豆包AI生成
function formatTimeToArray(date) {
  const hours24 = date.getHours()
  const hours12 = hours24 % 12 || 12
  const ampm = hours24 < 12 ? 'AM' : 'PM'
  const pad2 = (n) => n.toString().padStart(2, '0')

  return [
    pad2(hours12),        // 小时
    pad2(date.getMinutes()), // 分钟
    pad2(date.getSeconds()), // 秒
    ampm                  // AM/PM
  ]
}

export default {
  name: 'Hello',
  state: {
    name: '', // 姓名
    hello: '', // 欢迎语
    timeHour: '00', // 现在小时
    timeMinutes: '00', // 现在分钟
    timeSeconds: '00', // 现在秒
    timeHalf: '--', // 上午下午
  },

  setup () {
    this.updateTick()
  },

  actions: {
    sayHello () {
      this.hello = '您好,' + this.name
    },
    updateTick () {
      [this.timeHour, this.timeMinutes, this.timeSeconds, this.timeHalf] = formatTimeToArray(new Date())
      setTimeout(() => {
        // [this.timeHour, this.timeMinutes, this.timeSeconds, this.timeHalf] = formatTimeToArray(new Date())
        this.updateTick()
      }, 1000) 
    }
  }
}
