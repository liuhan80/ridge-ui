
export default {
  name: 'RidgeRepoExploer',
  state: {
    currentTab: 'app',
    tabs: [{
      label: '应用',
      value: 'app'
    }, { 
      label: '组件',
      value: 'component'
    }]
  }
}
